<?php
// HAPUS FILE INI SETELAH SELESAI DIGUNAKAN
set_time_limit(300);

$root = __DIR__;

echo "<pre style='font-family:monospace;font-size:13px;'>";
echo "=== RUN DATABASE MIGRATION ===\n\n";

exec("cd $root && php artisan migrate --force 2>&1", $output, $return);
echo implode("\n", $output);
echo "\n\nExit code: $return";
echo "\n\n" . ($return === 0 ? "✅ SUKSES" : "❌ GAGAL");
echo "</pre>";
