<?php
set_time_limit(300);
ini_set('memory_limit', '512M');

$root = __DIR__;
$composerPhar = $root . '/composer.phar';
$composerHome = $root . '/.composer-home';

if (!is_dir($composerHome)) {
    mkdir($composerHome, 0755, true);
}

putenv("COMPOSER_HOME=$composerHome");
putenv("HOME=$root");

echo "<pre style='font-family:monospace;font-size:13px;'>";
echo "=== INSTALL COMPOSER DEPENDENCIES ===\n\n";
echo "Root: $root\n";
echo "COMPOSER_HOME: $composerHome\n";
echo "composer.phar: " . (file_exists($composerPhar) ? "✅ ADA" : "❌ TIDAK ADA") . "\n\n";

if (!file_exists($composerPhar)) {
    echo "❌ GAGAL: Upload composer.phar ke folder: $root\n";
    exit;
}

echo "▶ Running composer install...\n\n";
exec("COMPOSER_HOME=$composerHome HOME=$root cd $root && php $composerPhar install --no-dev --optimize-autoloader --ignore-platform-req=ext-iconv 2>&1", $output, $return);
echo implode("\n", $output);
echo "\n\nExit code: $return";
echo "\n\n" . ($return === 0 ? "✅ SUKSES" : "❌ GAGAL");
echo "</pre>";