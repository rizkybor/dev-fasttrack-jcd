<?php
// HAPUS FILE INI SETELAH SELESAI DIGUNAKAN
set_time_limit(120);

$root = __DIR__;

echo "<pre style='font-family:monospace;font-size:13px;'>";
echo "=== GENERATE APP KEY ===\n\n";

// Cek apakah .env sudah ada APP_KEY
$env = file_get_contents("$root/.env");
if (strpos($env, 'APP_KEY=base64:') !== false) {
    echo "⚠️  APP_KEY sudah ada di .env, skip generate.\n";
    echo "Isi APP_KEY saat ini:\n";
    preg_match('/APP_KEY=(.+)/', $env, $m);
    echo $m[1] ?? '-';
} else {
    exec("cd $root && php artisan key:generate --force 2>&1", $output, $return);
    echo implode("\n", $output);
    echo "\n\nExit code: $return";
    echo "\n\n" . ($return === 0 ? "✅ SUKSES" : "❌ GAGAL");
}
echo "</pre>";
