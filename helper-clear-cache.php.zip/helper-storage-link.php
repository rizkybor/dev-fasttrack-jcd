<?php
// HAPUS FILE INI SETELAH SELESAI DIGUNAKAN
set_time_limit(60);

$root = __DIR__;

echo "<pre style='font-family:monospace;font-size:13px;'>";
echo "=== CREATE STORAGE SYMLINK ===\n\n";

exec("cd $root && php artisan storage:link 2>&1", $output, $return);
echo implode("\n", $output);
echo "\n\nExit code: $return";
echo "\n\n" . ($return === 0 ? "✅ SUKSES" : "❌ GAGAL (mungkin sudah ada)");
echo "</pre>";
