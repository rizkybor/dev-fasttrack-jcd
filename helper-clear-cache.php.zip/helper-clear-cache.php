<?php
// HAPUS FILE INI SETELAH SELESAI DIGUNAKAN
set_time_limit(120);

$root = __DIR__;

echo "<pre style='font-family:monospace;font-size:13px;'>";
echo "=== CLEAR & CACHE ===\n\n";

$commands = [
    'config:clear'  => 'Clear config cache',
    'cache:clear'   => 'Clear app cache',
    'view:clear'    => 'Clear view cache',
    'route:clear'   => 'Clear route cache',
    'config:cache'  => 'Cache config',
    'route:cache'   => 'Cache routes',
    'view:cache'    => 'Cache views',
];

foreach ($commands as $cmd => $label) {
    echo "▶ $label ($cmd)...\n";
    exec("cd $root && php artisan $cmd 2>&1", $output, $return);
    echo implode("\n", $output) . "\n";
    echo ($return === 0 ? "  ✅ OK" : "  ❌ GAGAL") . "\n\n";
    $output = [];
}

// Fix storage permission
exec("chmod -R 755 $root/storage $root/bootstrap/cache 2>&1", $output2);
echo "▶ Fix storage permissions...\n";
echo implode("\n", $output2) . "\n✅ OK\n";

echo "\n=== SELESAI ===";
echo "</pre>";
